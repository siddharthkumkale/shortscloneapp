package com.example.shortsapp

import android.os.Bundle
import android.os.PersistableBundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.viewpager2.widget.ViewPager2
import android.view.Menu
import android.view.MenuItem
import com.example.shortsapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val arrayList: ArrayList<Model> = ArrayList()
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide();
        arrayList.add(Model("android.resource://" + packageName + "/" + R.raw.a, R.drawable.profileuser, "@Siddharth Kum"))
        arrayList.add(Model("android.resource://" + packageName + "/" + R.raw.b, R.drawable.profileuser, "@Dishant"))
        adapter = Adapter(this, arrayList)
        binding.Vpg2.adapter = adapter
    }
}




